<!--拔河层-->
<script type="text/javascript">
$(function(){
    $(document).keydown(function (event)
        {   
        if(event.keyCode == 66){
        				window.open(webroot+'/tug/');
        			}
        });  
});
</script>
